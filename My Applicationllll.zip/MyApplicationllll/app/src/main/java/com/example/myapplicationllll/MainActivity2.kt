package com.example.myapplicationllll


import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.Button
import android.widget.CalendarView
import androidx.appcompat.app.AlertDialog
import com.google.android.material.switchmaterial.SwitchMaterial
import android.app.NotificationManager


class MainActivity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        val notificationSwitch: SwitchMaterial = findViewById(R.id.plan_sw)

        createNo

        notificationSwitch.setOnCheckedChangeListener { buttonView, isChecked ->
            if (isChecked) {

            } else {
        }











        val button1 = findViewById<Button>(R.id.color_1)
        val calendarView: CalendarView = findViewById(R.id.calenderview)

        // 초기 색상 설정
        calendarView.setBackgroundColor(Color.parseColor("#D34989"))

        button1.setOnClickListener {
            // 버튼을 클릭할 때마다 CalendarView의 배경색을 #D34989로 변경
            calendarView.setBackgroundColor(Color.parseColor("#D34989"))
        }

        val button2 = findViewById<Button>(R.id.color_2)
        val calendarView: CalendarView = findViewById(R.id.calenderview)

        // 초기 색상 설정
        calendarView.setBackgroundColor(Color.parseColor("#EDDE55"))

        button2.setOnClickListener {
            // 버튼을 클릭할 때마다 CalendarView의 배경색을 #D34989로 변경
            calendarView.setBackgroundColor(Color.parseColor("#EDDE55"))
        }

        val button3 = findViewById<Button>(R.id.color_3)
        val calendarView: CalendarView = findViewById(R.id.calenderview)

        // 초기 색상 설정
        calendarView.setBackgroundColor(Color.parseColor("#75EA7A"))

        button3.setOnClickListener {
            // 버튼을 클릭할 때마다 CalendarView의 배경색을 #D34989로 변경
            calendarView.setBackgroundColor(Color.parseColor("#75EA7A"))
        }

        val button4 = findViewById<Button>(R.id.color_4)
        val calendarView: CalendarView = findViewById(R.id.calenderview)

        // 초기 색상 설정
        calendarView.setBackgroundColor(Color.parseColor("#75EA7A"))

        button4.setOnClickListener {
            // 버튼을 클릭할 때마다 CalendarView의 배경색을 #D34989로 변경
            calendarView.setBackgroundColor(Color.parseColor("#75EA7A"))
        }
    }
}